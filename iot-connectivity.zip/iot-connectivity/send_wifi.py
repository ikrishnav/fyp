from network import WLAN
from simple import MQTTClient
import time
import ubinascii
import json
from pycoproc_2 import Pycoproc
from SI7006A20 import SI7006A20

# === Configuration ===
SSID = 'NOKIA-79A1'
PASSWORD = 'UZY4Z3tr4K'
DEVICE_ID = 'fipy-wifi-unit-01'
MQTT_BROKER = '192.168.18.41'  # <-- Replace with your PC IP if needed
MQTT_TOPIC = 'iot/wifi'

# === Function to connect to Wi-Fi ===
def connect_wifi(ssid, password):
    wlan = WLAN(mode=WLAN.STA)
    if not wlan.isconnected():
        print("📶 Connecting to Wi-Fi...")
        wlan.connect(ssid=ssid, auth=(WLAN.WPA2, password))
        timeout = 20
        while not wlan.isconnected() and timeout > 0:
            time.sleep(1)
            timeout -= 1
            print(".", end='')
    if wlan.isconnected():
        print("\n✅ Wi-Fi connected:", wlan.ifconfig())
        return wlan
    else:
        print("\n❌ Failed to connect to Wi-Fi.")
        return None

# === Main Script ===
wlan = connect_wifi(SSID, PASSWORD)
if not wlan:
    raise Exception("Wi-Fi connection failed. Aborting script.")

# === Connect to MQTT ===
client = MQTTClient(client_id=DEVICE_ID, server=MQTT_BROKER, port=1883)
#client.set_debug(True)  # <-- Enable MQTT debug
try:
    client.connect()
    print("📡 MQTT connected.")
except Exception as e:
    print("❌ MQTT connection failed:", e)
    raise

# === Read from SI7006A20 Sensor ===
try:
    py = Pycoproc()
    si = SI7006A20(py)
    temperature = si.temperature()
    humidity = si.humidity()
    timestamp = time.time()

    print("🌡️ Temperature:", temperature)
    print("💧 Humidity:", humidity)
    print("⏱️ Timestamp:", timestamp)

    # === Create Payload ===
    payload = {
        "device_id": DEVICE_ID,
        "timestamp": timestamp,
        "temperature": temperature,
        "humidity": humidity
    }

    payload_json = json.dumps(payload)
    print("📦 Payload JSON:", payload_json)

    # === Publish Data ===
    client.publish(MQTT_TOPIC, payload_json)
    print("✅ MQTT Published Wi-Fi Data:", payload)

except Exception as e:
    print("❌ Error in sensor reading or publish:", e)

finally:
    client.disconnect()
    print("🔌 MQTT disconnected.")
